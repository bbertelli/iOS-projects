//
//  ListaContatosViewController.m
//  ContatosIP67
//
//  Created by ios4230 on 10/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import "ListaContatosViewController.h"
#import "FormularioContatoViewController.h"
#import "Contato.h"

@implementation ListaContatosViewController

- (id)init{
    if (self = [super initWithStyle:UITableViewStyleGrouped]) {
        self.title = @"Contatos";
//        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"+"
//                                                                                  style:UIBarButtonSystemItemAdd
//                                                                                 target:self
//                                                                                 action:@selector(mudaDeTela)];
        
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd
                                                                                               target:self
                                                                                               action:@selector(mudaDeTela)];
        self.navigationItem.leftBarButtonItem = self.editButtonItem;
    }
    return self;
}

-(id)initWithContatos:(NSMutableArray *)contatos{
    if (self = [self init]) {
        self.contatos = contatos;
    }
    return self;
}

- (void) mudaDeTela{
    FormularioContatoViewController *formulario = [[FormularioContatoViewController alloc] init];
    formulario.contatos = self.contatos;
    formulario.delegate = self;
    //modo de navegacao que cria novamente a tela e uma nova barrinha
    //UINavigationController *novaBarrinha = [[UINavigationController alloc] initWithRootViewController:formulario];
    //[self presentViewController:novaBarrinha
    //                   animated:YES
    //                 completion:nil];
    
    //modo de navegacao que troca uma tela pela outra na barrinha
    [self.navigationController pushViewController:formulario
                                         animated:YES];
}

- (void) contatoAtualizado:(Contato *)contato{
    NSLog(@"Contato Atualizado: %d", [self.contatos indexOfObject:contato]);
}

- (void) contatoAdicionado:(Contato *)contato{
    NSLog(@"Contato Adicionado: %d", [self.contatos indexOfObject:contato]);
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.contatos count];
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(!cell){
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault
                                     reuseIdentifier:cellIdentifier];
    }
    
    Contato *contato = self.contatos[indexPath.row];
    cell.textLabel.text = contato.nome;
    
    return cell;
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle
                                           forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.contatos removeObjectAtIndex:indexPath.row];
        [self.tableView deleteRowsAtIndexPaths:@[indexPath]
                              withRowAnimation:UITableViewRowAnimationFade];
    }
    
}

-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    Contato *contatoParaEditar = self.contatos[indexPath.row];
    FormularioContatoViewController *formulario = [[FormularioContatoViewController alloc] initWithContato:contatoParaEditar];
    formulario.contato = contatoParaEditar;
    formulario.delegate = self;
    
    [self.navigationController pushViewController:formulario animated:YES];
}

- (void) viewWillAppear:(BOOL)animated{
    [self.tableView reloadData];
}

@end
