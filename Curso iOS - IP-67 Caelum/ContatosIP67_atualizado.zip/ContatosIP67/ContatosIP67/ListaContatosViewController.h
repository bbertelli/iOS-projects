//
//  ListaContatosViewController.h
//  ContatosIP67
//
//  Created by ios4230 on 10/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ListaContatosProtocol.h"

@interface ListaContatosViewController : UITableViewController<ListaContatosProtocol>

@property (nonatomic, weak) NSMutableArray *contatos;

-(id)initWithContatos:(NSMutableArray*)contatos;

@end
