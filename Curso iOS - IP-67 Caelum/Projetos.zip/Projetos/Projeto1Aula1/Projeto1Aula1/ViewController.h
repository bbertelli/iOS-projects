//
//  ViewController.h
//  Projeto1Aula1
//
//  Created by ios4230 on 03/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

    @property (weak,nonatomic) IBOutlet UILabel *texto;
    @property IBOutlet UITextField *campo;

@property float saldo;

-(IBAction)cliqueMaroto:(id)sender;

@end
