//
//  ViewController.m
//  Projeto1Aula1
//
//  Created by ios4230 on 03/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)cliqueMaroto:(id)sender{
    NSLog(@"Texto na tela: %@",self.campo.text); //imprimir no console o valor da variável
//    self.texto.text = [self.campo text]; //exemplo de getter
//    NSLog(@"Texto do botão: %@",self.botao.text);
    
    [self.texto setText:[self.campo text]]; //exemplo de setter
//    UILabel *outroTexto = (UILabel*)[self.view viewWithTag:123]; //ligar o objeto por tag
    
    NSString *textoDigitado = @"100.50";
    float numeroDigitado = [textoDigitado floatValue];
    NSString *numeroFormatado = [NSString stringWithFormat:@"R$%.2f",numeroDigitado];
    self.saldo = numeroDigitado;
//    NSString *frase = [NSString stringWithFormat:@"Sou o %@ @%", @"Fulano",@"de tal" ];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
