//
//  Conta.m
//  DesafioAula1
//
//  Created by ios4230 on 03/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import "Conta.h"

@implementation Conta

-(BOOL)saca:(float)valor{
    if(self.saldo >= valor){
        self.saldo -= valor;
        return YES;
    }
    return NO;
}

-(void)deposita:(float)valor{
    self.saldo += valor;
}

-(void)transfereOValor:(float)valor paraODestino:(Conta*)destino{
    [self saca:valor];
    [destino deposita:valor];
}

@end
