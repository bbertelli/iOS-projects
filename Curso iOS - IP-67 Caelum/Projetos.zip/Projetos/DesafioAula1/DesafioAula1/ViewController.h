//
//  ViewController.h
//  DesafioAula1
//
//  Created by ios4230 on 03/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Conta.h"
@interface ViewController : UIViewController

//@property float saldo;
@property(strong,nonatomic) Conta *cc;
@property(strong,nonatomic) Conta *cp;
@property IBOutlet UILabel *valor;
@property IBOutlet UITextField *campoValor;

//-(IBAction)deposita:(id)sender;
//-(IBAction)saca:(id)sender;
@end
