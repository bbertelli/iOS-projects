//
//  Conta.h
//  DesafioAula1
//
//  Created by ios4230 on 03/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Conta : NSObject

@property float saldo;

-(BOOL)saca:(float)valor;
-(void)deposita:(float)valor;
-(void)transfereOValor:(float)valor paraODestino:(Conta*)destino;

@end
