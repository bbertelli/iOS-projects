//
//  AppDelegate.h
//  DesafioAula1
//
//  Created by ios4230 on 03/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
