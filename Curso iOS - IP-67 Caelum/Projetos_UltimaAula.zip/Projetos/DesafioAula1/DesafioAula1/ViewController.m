//
//  ViewController.m
//  DesafioAula1
//
//  Created by ios4230 on 03/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.campoValor.keyboardType = UIKeyboardTypeNumberPad; //muda o teclado para apenas numérico
    self.cc = [Conta new];
    [self.cc deposita:200];
    self.cp = [Conta new];
    [self.cc transfereOValor:50 paraODestino:self.cp];
	// Do any additional setup after loading the view, typically from a nib.
    NSLog(@"Saldo CC: %.2f Saldo CP: %.2f", self.cc.saldo, self.cp.saldo);
}

- (IBAction)saca:(id)sender{
    float valorDigitado = [self.campoValor.text floatValue];
    [self.cc saca:valorDigitado];
    [self atualizaSaldoNaTela];
}

- (IBAction)deposita:(id)sender{
    float valorDigitado = [self.campoValor.text floatValue];
    [self.cc deposita:valorDigitado];
    [self atualizaSaldoNaTela];
    
}

-(void)atualizaSaldoNaTela{
    NSString *novoSaldo = [NSString stringWithFormat:@"%.2f",self.cc.saldo];
    self.valor.text = novoSaldo;
    [self.campoValor setText:@""]; //limpa o campo digitacao
}

//- (IBAction)deposita:(id)sender{
//
//    self.saldo = [self.valor.text floatValue]; //valor do saldo atual
//    
//    float saldoDigitado = [self.campoValor.text floatValue]; //pega o valor digitado
//    float novoSaldo = self.saldo + saldoDigitado; //soma o saldo atual com o valor digitado
//    NSString *novoSaldoFormatado = [NSString stringWithFormat:@"%.2f",novoSaldo]; //formata o valor para string
//    [self.valor setText:novoSaldoFormatado]; //seta o label de saldo
//    [self.campoValor setText:@""]; //limpa o campo digitacao
//}
//
//- (IBAction)saca:(id)sender{
//    
//    self.saldo = [self.valor.text floatValue]; //valor do saldo atual
//    
//    float saldoDigitado = [self.campoValor.text floatValue]; //pega o valor digitado
//    float novoSaldo = self.saldo - saldoDigitado; //subtrai o saldo atual pelo valor digitado
//    NSString *novoSaldoFormatado = [NSString stringWithFormat:@"%.2f",novoSaldo]; //formata o valor para string
//    [self.valor setText:novoSaldoFormatado]; //seta o label de saldo
//    [self.campoValor setText:@""]; //limpa o campo de digitacao
//    
//}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
