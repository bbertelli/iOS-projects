//
//  FormularioContatoViewController.h
//  ContatosIP67
//
//  Created by ios4230 on 10/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Contato.h"
#import "ListaContatosProtocol.h"
#import <CoreLocation/CoreLocation.h>


@interface FormularioContatoViewController : UIViewController<UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIActionSheetDelegate>
@property (weak, nonatomic) IBOutlet UITextField *nome;
@property (weak, nonatomic) IBOutlet UITextField *telefone;
@property (weak, nonatomic) IBOutlet UITextField *email;
@property (weak, nonatomic) IBOutlet UITextField *end;
@property (weak, nonatomic) IBOutlet UITextField *site;
@property (strong, nonatomic) NSArray *campoEmOrdem;
//@property (strong, nonatomic) NSMutableArray *contatos;
@property (strong, nonatomic) Contato *contato;
@property (weak, nonatomic) id<ListaContatosProtocol> delegate;
@property (weak, nonatomic) IBOutlet UIButton *botaoFoto;
- (IBAction)selecionaFoto:(id)sender;
- (IBAction)buscarCoordenadas:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *latitude;
@property (weak, nonatomic) IBOutlet UITextField *longitude;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *loading;

//- (IBAction)pegaDadosDoFormulario:(id)sender;
- (IBAction)proximoElemento:(UITextField *)campoEmFoco;
- (id) initWithContato:(Contato *) umContato;

@end
