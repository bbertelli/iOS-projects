//
//  ListaContatosViewController.h
//  ContatosIP67
//
//  Created by ios4230 on 10/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import <MessageUI/MFMailComposeViewController.h>
#import <Foundation/Foundation.h>
#import "ListaContatosProtocol.h"

@interface ListaContatosViewController : UITableViewController<ListaContatosProtocol, UIActionSheetDelegate, MFMailComposeViewControllerDelegate>{
    Contato* contatoSelecionado;
}

@property (nonatomic, weak) NSMutableArray *contatos;
@property NSInteger linhaDestaque;

-(id)initWithContatos:(NSMutableArray*)contatos;
-(void) exibeMaisAcoes:(UIGestureRecognizer *) gesture;

@end
