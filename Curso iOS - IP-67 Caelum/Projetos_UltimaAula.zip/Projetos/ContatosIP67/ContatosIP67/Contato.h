//
//  Contato.h
//  ContatosIP67
//
//  Created by ios4230 on 10/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MKAnnotation.h>

@interface Contato : NSObject<NSCoding, MKAnnotation>

@property NSString *nome;
@property NSString *telefone;
@property NSString *email;
@property NSString *end;
@property NSString *site;
@property (strong) UIImage *foto;
@property (strong) NSNumber *latitude;
@property (strong) NSNumber *longitude;

@end
