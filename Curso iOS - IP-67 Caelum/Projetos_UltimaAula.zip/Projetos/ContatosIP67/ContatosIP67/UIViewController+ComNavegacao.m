//
//  UIViewController+ComNavegacao.m
//  ContatosIP67
//
//  Created by ios4230 on 31/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import "UIViewController+ComNavegacao.h"

@implementation UIViewController (ComNavegacao)

- (UINavigationController *) comBarrinha{
    return [[UINavigationController alloc] initWithRootViewController:self];
}

@end
