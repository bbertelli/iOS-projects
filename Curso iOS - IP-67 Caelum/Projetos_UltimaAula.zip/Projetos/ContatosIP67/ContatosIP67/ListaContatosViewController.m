//
//  ListaContatosViewController.m
//  ContatosIP67
//
//  Created by ios4230 on 10/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import "ListaContatosViewController.h"
#import "FormularioContatoViewController.h"
#import "Contato.h"

@implementation ListaContatosViewController

- (id)init{
    self.linhaDestaque = -1;
    if (self = [super initWithStyle:UITableViewStyleGrouped]) {
        UIImage *imageTabItem = [UIImage imageNamed:@"lista-contatos.png"];
        UITabBarItem *tabItem = [[UITabBarItem alloc] initWithTitle:@"Contatos" image:imageTabItem tag:0];
        
        self.tabBarItem = tabItem;
        self.navigationItem.title = @"Contatos";
        
        self.title = @"Contatos";
//        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"+"
//                                                                                  style:UIBarButtonSystemItemAdd
//                                                                                 target:self
//                                                                                 action:@selector(mudaDeTela)];
        
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd
                                                                                               target:self
                                                                                               action:@selector(mudaDeTela)];
        self.navigationItem.leftBarButtonItem = self.editButtonItem;
    }
    return self;
}

-(id)initWithContatos:(NSMutableArray *)contatos{
    if (self = [self init]) {
        self.contatos = contatos;
    }
    return self;
}

/*//Exemplo de criação de long clique (que não existe na API)

//Criar componente programático na tela que escuta um clique
    -(void) viewDidLoad{
        UIButton *btn = [[UIButton alloc] init]; //cria o botão
        [self.view addSubview:btn]; //insere o botão na tela
        UITapGestureRecognizer *reco = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(botaoClicado)]; //cria um listener de clique
        [btn addGestureRecognizer:reco]; //linka o listener ao botão
    }

    -(void) botaoClicado{
    
    }
*///Criar componente programático na tela que escuta um clique longo
-(void) viewDidLoad{
    UILongPressGestureRecognizer *orelha = [[UILongPressGestureRecognizer alloc]
                                            initWithTarget:self
                                            action:@selector(exibeMaisAcoes:)]; //cria um listener para long clique
    [self.tableView addGestureRecognizer:orelha]; //linka o listener ao table
}

-(void) exibeMaisAcoes:(UIGestureRecognizer *) gesture{
    if (gesture.state == UIGestureRecognizerStateBegan) {
        
    CGPoint ponto = [gesture locationInView:self.tableView];
    NSIndexPath *path = [self.tableView indexPathForRowAtPoint:ponto];
        
        Contato *contato = self.contatos[path.row];
        contatoSelecionado = contato;
        
    UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:@"Opções"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancelar"
                                         destructiveButtonTitle:nil
                                              otherButtonTitles:@"Ligar", @"E-mail", @"Site", @"Mapa", nil];
        [sheet showInView:self.view];
    }
}

-(void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:
            [self ligar];
            break;
        case 1 :
            [self enviarEmail];
            break;
        case 2:
            [self abrirSite];
            break;
        case 3:
            [self mostrarMapa];
            break;
            
        default:
            break;
    }
}

-(void) abrirAplicativoComURL:(NSString *) url{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url]];
}

-(void) ligar{
    UIDevice *device = [UIDevice currentDevice];
    if ([device.model isEqualToString:@"iPhone"]) {
        NSString *numero = [NSString stringWithFormat:@"tel:%@", contatoSelecionado.telefone];
        [self abrirAplicativoComURL:numero];
    } else {
        [[[UIAlertView alloc] initWithTitle:@"Impossível fazer ligação"
                                    message:@"Seu dispositivo não é um iPhone"
                                   delegate:nil
                          cancelButtonTitle:@"Ok"
                          otherButtonTitles:nil] show];
    }
}

-(void) abrirSite{
    NSRange range = [contatoSelecionado.site rangeOfString:@"http://"];
    NSString *url = contatoSelecionado.site;
    
    if (range.location == NSNotFound) {
        url = [NSString stringWithFormat:@"http://%@",contatoSelecionado.site];
    }

    
    [self abrirAplicativoComURL:url];
}

-(void) mostrarMapa{
    NSString *url = [[NSString stringWithFormat:@"http://maps.google.com/maps?q=%@", contatoSelecionado.end] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [self abrirAplicativoComURL:url];
}

-(void) enviarEmail {
    if ([MFMailComposeViewController canSendMail]) {
        MFMailComposeViewController *enviadorEmail = [[MFMailComposeViewController alloc] init];
        enviadorEmail.mailComposeDelegate = self;
        
        [enviadorEmail setToRecipients:@[contatoSelecionado.email]];
        [enviadorEmail setSubject:@"Caelum"];
        
        [self presentViewController:enviadorEmail animated:YES completion:nil];
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Oops!"
                                                        message:@"Não é possível enviar e-mail"
                                                       delegate:nil
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil];
        [alert show];
    }
}

- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void) mudaDeTela{
    FormularioContatoViewController *formulario = [[FormularioContatoViewController alloc] init];
    //formulario.contatos = self.contatos;
    formulario.delegate = self;
    //modo de navegacao que cria novamente a tela e uma nova barrinha
    //UINavigationController *novaBarrinha = [[UINavigationController alloc] initWithRootViewController:formulario];
    //[self presentViewController:novaBarrinha
    //                   animated:YES
    //                 completion:nil];
    
    //modo de navegacao que troca uma tela pela outra na barrinha
    [self.navigationController pushViewController:formulario
                                         animated:YES];
}

- (void) contatoAtualizado:(Contato *)contato{
    self.linhaDestaque = [self.contatos indexOfObject:contato];
    NSLog(@"Contato Atualizado: %d", [self.contatos indexOfObject:contato]);
}

- (void) contatoAdicionado:(Contato *)contato{
    [self.contatos addObject:contato];
    self.linhaDestaque = [self.contatos indexOfObject:contato];
    [self.tableView reloadData];
    NSLog(@"Contato Adicionado: %d", [self.contatos indexOfObject:contato]);
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.contatos count];
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(!cell){
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault
                                     reuseIdentifier:cellIdentifier];
    }
    
    Contato *contato = self.contatos[indexPath.row];
    cell.textLabel.text = contato.nome;
    
    return cell;
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle
                                           forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.contatos removeObjectAtIndex:indexPath.row];
        [self.tableView deleteRowsAtIndexPaths:@[indexPath]
                              withRowAnimation:UITableViewRowAnimationFade];
    }
    
}

-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    Contato *contatoParaEditar = self.contatos[indexPath.row];
    FormularioContatoViewController *formulario = [[FormularioContatoViewController alloc] initWithContato:contatoParaEditar];
    formulario.contato = contatoParaEditar;
    formulario.delegate = self;
    
    [self.navigationController pushViewController:formulario animated:YES];
}

- (void) viewWillAppear:(BOOL)animated{
    [self.tableView reloadData];
}

- (void) viewDidAppear:(BOOL)animated{
    if(self.linhaDestaque >= 0) {
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.linhaDestaque inSection:0];
    [self.tableView selectRowAtIndexPath:indexPath animated:YES scrollPosition:UITableViewScrollPositionNone];
        [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionNone animated:YES];
        self.linhaDestaque = -1;
    }
}

@end
