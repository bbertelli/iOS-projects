//
//  UIViewController+ComNavegacao.h
//  ContatosIP67
//
//  Created by ios4230 on 31/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (ComNavegacao)

- (UINavigationController *) comBarrinha;

@end
