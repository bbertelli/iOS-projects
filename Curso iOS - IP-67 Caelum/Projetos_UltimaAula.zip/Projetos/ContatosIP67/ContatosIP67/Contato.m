//
//  Contato.m
//  ContatosIP67
//
//  Created by ios4230 on 10/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import "Contato.h"

@implementation Contato

- (CLLocationCoordinate2D)coordinate {
    return CLLocationCoordinate2DMake ([self.latitude doubleValue], [self.longitude doubleValue]);
}

- (NSString *)title{
    return self.nome;
}

- (NSString *)subtitle{
    return self.email;
}

-(NSString *)description{
    return [NSString stringWithFormat:@"\nNome: %@\nTelefone: %@\nEmail: %@\nEndereço: %@\nSite: %@", self.nome,self.telefone,self.email,self.end,self.site];
}

-(void) encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.nome forKey:@"nome"];
    [aCoder encodeObject:self.telefone forKey:@"telefone"];
    [aCoder encodeObject:self.email forKey:@"email"];
    [aCoder encodeObject:self.end forKey:@"end"];
    [aCoder encodeObject:self.site forKey:@"site"];
    [aCoder encodeObject:self.foto forKey:@"foto"];
    [aCoder encodeObject:self.latitude forKey:@"latitude"];
    [aCoder encodeObject:self.longitude forKey:@"longitude"];
}

-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    if (self) {
        [self setNome:[aDecoder decodeObjectForKey:@"nome"]];
        [self setTelefone:[aDecoder decodeObjectForKey:@"telefone"]];
        [self setEmail:[aDecoder decodeObjectForKey:@"email"]];
        [self setEnd:[aDecoder decodeObjectForKey:@"end"]];
        [self setSite:[aDecoder decodeObjectForKey:@"site"]];
        [self setFoto:[aDecoder decodeObjectForKey:@"foto"]];
        [self setLatitude:[aDecoder decodeObjectForKey:@"latitude"]];
        [self setLongitude:[aDecoder decodeObjectForKey:@"longitude"]];
    }
    
    return self;
}

@end
