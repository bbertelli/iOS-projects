//
//  Contato.m
//  ContatosComBD
//
//  Created by ios4230 on 31/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import "Contato.h"


@implementation Contato

@dynamic nome;
@dynamic end;
@dynamic email;
@dynamic site;
@dynamic telefone;
@dynamic latitude;
@dynamic longitude;

@end
