//
//  Contato.h
//  ContatosComBD
//
//  Created by ios4230 on 31/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Contato : NSManagedObject

@property (nonatomic, retain) NSString * nome;
@property (nonatomic, retain) NSString * end;
@property (nonatomic, retain) NSString * email;
@property (nonatomic, retain) NSString * site;
@property (nonatomic, retain) NSString * telefone;
@property (nonatomic, retain) NSDecimalNumber * latitude;
@property (nonatomic, retain) NSDecimalNumber * longitude;

@end
