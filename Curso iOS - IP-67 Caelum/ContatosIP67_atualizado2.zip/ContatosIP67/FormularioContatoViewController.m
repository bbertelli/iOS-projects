//
//  FormularioContatoViewController.m
//  ContatosIP67
//
//  Created by ios4230 on 10/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import "FormularioContatoViewController.h"
#import "Contato.h"

@interface FormularioContatoViewController ()

@end

@implementation FormularioContatoViewController

- (id)init{
    self = [super init];
    if (self) {
        //self.contatos = [[NSMutableArray alloc] init];
        
        self.navigationItem.title = @"Cadastro";
        
        //Cria o botão com texto
        UIBarButtonItem *cancelar = [[UIBarButtonItem alloc] initWithTitle:@"Cancelar"
                                                                     style:UIBarButtonItemStylePlain
                                                                    target:self
                                                                    action:@selector(escondeFormulario)];
        
        self.navigationItem.leftBarButtonItem = cancelar;
        
        //Cria o botão com icone
        //        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel
        //                                                                                  target:self
        //                                                                                  action:@selector(escondeFormulario)];
        
        
        
        
        UIBarButtonItem *adicionar = [[UIBarButtonItem alloc] initWithTitle:@"Adicionar"
                                                                      style:UIBarButtonItemStylePlain
                                                                     target:self
                                                                     action:@selector(criaContato)];
        self.navigationItem.rightBarButtonItem = adicionar;
    }
    return self;
}

-(id) initWithContato:(Contato *) umContato{
    if (self = [self init]) {
        self.contato = umContato;
        
        
        UIBarButtonItem *salvarEdicao = [[UIBarButtonItem alloc] initWithTitle:@"Salvar"
                                                                      style:UIBarButtonItemStylePlain
                                                                     target:self
                                                                     action:@selector(atualizaContato:)];
        self.navigationItem.rightBarButtonItem = salvarEdicao;
        
        //NSLog(@"Contatos editados: %d", [self.contatos count]);
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if (self.contato) {
        self.nome.text = self.contato.nome;
        self.telefone.text = self.contato.telefone;
        self.email.text = self.contato.email;
        self.end.text = self.contato.end;
        self.site.text = self.contato.site;
        
        if (self.contato.foto) {
            [self.botaoFoto setImage:self.contato.foto forState:UIControlStateNormal];
        }
    }
    // Do any additional setup after loading the view from its nib.
    [self.nome becomeFirstResponder];
    self.campoEmOrdem = @[self.nome,self.telefone,self.email,self.end,self.site];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (Contato *)pegaDadosDoFormulario {

    if (!self.contato) {
        self.contato = [[Contato alloc] init];
    }
    
    if (self.botaoFoto.imageView.image) {
        self.contato.foto = self.botaoFoto.imageView.image;
    }
    //dot notation
    //Contato *contato = [[Contato alloc]init];
    self.contato.nome = self.nome.text;
    self.contato.telefone = self.telefone.text;
    self.contato.email = self.email.text;
    self.contato.end = self.end.text;
    self.contato.site = self.site.text;
    //NSLog(@"Dados do Contato: %@", contato.nome); //imprimindo normalmente
    //[self.contatos addObject:contato]; //adiciona o contato ao array de contatos
    //NSLog(@"Contatos: %@", self.contatos); //imprimindo utilizando o description (semelhante ao toString)
    //[self.site resignFirstResponder]; //ultimo campo, fala pra ele esconder o teclado
    [self.view endEditing:YES]; //verifica qual é o ultimo campo e fala pra ele esconder o teclado
    return self.contato;
    
//  Utilizando o NSDictionary
//    NSMutableDictionary *dadosDoContato = [[NSMutableDictionary alloc]init];
//    [dadosDoContato setObject:[self.nome text] forKey:@"nome"];
//    [dadosDoContato setObject:[self.telefone text] forKey:@"telefone"];
//    [dadosDoContato setObject:[self.email text] forKey:@"email"];
//    [dadosDoContato setObject:[self.end text] forKey:@"end"];
//    [dadosDoContato setObject:[self.site text] forKey:@"site"];
    
    //jeito normal do objective-c
//    Contato *contato = [[Contato alloc]init];
//    contato.nome = [[self nome] text];
//    contato.telefone = [[self telefone] text];
//    contato.email = [[self email] text];
//    contato.end = [[self end] text];
//    contato.site = [[self site] text];
//    NSLog(@"Dados do Contato: %@", [contato nome]);
}

- (IBAction)proximoElemento:(UITextField *)campoEmFoco{
    
    //método do livro
//    if (campoEmFoco == self.nome) {
//        [self.telefone becomeFirstResponder];
//    } else if (campoEmFoco == self.telefone){
//        [self.email becomeFirstResponder];
//    } else if (campoEmFoco == self.email){
//        [self.end becomeFirstResponder];
//    } else if (campoEmFoco == self.end){
//        [self.site becomeFirstResponder];
//    } else if (campoEmFoco == self.site){
//        [self.site resignFirstResponder];
//    }
     
    //método diferente
    int posicao = [self.campoEmOrdem indexOfObject:campoEmFoco];
    if (posicao == [self.campoEmOrdem count] -1) {
        [self.view endEditing:YES];
    }else{
        UITextField *proximoCampo = self.campoEmOrdem[posicao+1];
        [proximoCampo becomeFirstResponder];
    }
}

- (void) criaContato {
    Contato *novoContato = [self pegaDadosDoFormulario];
    //[self.contatos addObject:novoContato];
    //[self.contatos addObject:[self pegaDadosDoFormulario]];
    
    //NSLog(@"Contatos cadastrados: %d", [self.contatos count]);
    
    [self.navigationController popViewControllerAnimated:YES];
    
    if (self.delegate) {
        [self.delegate contatoAdicionado:novoContato];
    }
}

- (void) atualizaContato:(Contato *) umContato{
    Contato *contatoAtualizado = [self pegaDadosDoFormulario];
    //[self pegaDadosDoFormulario];
    [self.navigationController popViewControllerAnimated:YES];
    
    if (self.delegate) {
        [self.delegate contatoAtualizado:contatoAtualizado];
    }
}

- (void) escondeFormulario {
//    Nav. push (cabide)
    [self.navigationController popViewControllerAnimated:YES];
    
//    Nav. tipo modal
//    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)selecionaFoto:(id)sender{
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:@"Escolha a foto do contato" delegate:self cancelButtonTitle:@"Cancelar" destructiveButtonTitle:nil otherButtonTitles:@"Tirar foto", @"Escolher da biblioteca", nil];
        [sheet showInView:self.view];
    } else {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        picker.allowsEditing = YES;
        picker.delegate = self;
        [self presentViewController:picker animated:YES completion:^{
        [[[UIAlertView alloc] initWithTitle:@"Aviso!" message:@"Capriche!" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];
        }];
        
    }
}

-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    UIImage *imagemSelecionada = [info valueForKey:UIImagePickerControllerEditedImage];
    [self.botaoFoto setImage:imagemSelecionada forState:UIControlStateNormal];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    
    switch (buttonIndex) {
        case 0:
            picker.sourceType = UIImagePickerControllerSourceTypeCamera;
            break;
        case 1:
            picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            break;
            
        default:
            break;
    }
    
    [self presentViewController:picker animated:YES completion:nil];
}

- (void) viewWillAppear:(BOOL)animated{
    //NSLog(@"Total cadastrado: %d", [self.contatos count]);
}

@end
