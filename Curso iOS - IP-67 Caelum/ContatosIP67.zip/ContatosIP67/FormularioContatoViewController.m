//
//  FormularioContatoViewController.m
//  ContatosIP67
//
//  Created by ios4230 on 10/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import "FormularioContatoViewController.h"
#import "Contato.h"

@interface FormularioContatoViewController ()

@end

@implementation FormularioContatoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self.nome becomeFirstResponder];
    self.campoEmOrdem = @[self.nome,self.telefone,self.email,self.end,self.site];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (Contato *)pegaDadosDoFormulario {

    //dot notation
    Contato *contato = [[Contato alloc]init];
    contato.nome = self.nome.text;
    contato.telefone = self.telefone.text;
    contato.email = self.email.text;
    contato.end = self.end.text;
    contato.site = self.site.text;
    //NSLog(@"Dados do Contato: %@", contato.nome); //imprimindo normalmente
    //[self.contatos addObject:contato]; //adiciona o contato ao array de contatos
    //NSLog(@"Contatos: %@", self.contatos); //imprimindo utilizando o description (semelhante ao toString)
    //[self.site resignFirstResponder]; //ultimo campo, fala pra ele esconder o teclado
    [self.view endEditing:YES]; //verifica qual é o ultimo campo e fala pra ele esconder o teclado
    return contato;
    
//  Utilizando o NSDictionary
//    NSMutableDictionary *dadosDoContato = [[NSMutableDictionary alloc]init];
//    [dadosDoContato setObject:[self.nome text] forKey:@"nome"];
//    [dadosDoContato setObject:[self.telefone text] forKey:@"telefone"];
//    [dadosDoContato setObject:[self.email text] forKey:@"email"];
//    [dadosDoContato setObject:[self.end text] forKey:@"end"];
//    [dadosDoContato setObject:[self.site text] forKey:@"site"];
    
    //jeito normal do objective-c
//    Contato *contato = [[Contato alloc]init];
//    contato.nome = [[self nome] text];
//    contato.telefone = [[self telefone] text];
//    contato.email = [[self email] text];
//    contato.end = [[self end] text];
//    contato.site = [[self site] text];
//    NSLog(@"Dados do Contato: %@", [contato nome]);
}

- (IBAction)proximoElemento:(UITextField *)campoEmFoco{
    
    //método do livro
//    if (campoEmFoco == self.nome) {
//        [self.telefone becomeFirstResponder];
//    } else if (campoEmFoco == self.telefone){
//        [self.email becomeFirstResponder];
//    } else if (campoEmFoco == self.email){
//        [self.end becomeFirstResponder];
//    } else if (campoEmFoco == self.end){
//        [self.site becomeFirstResponder];
//    } else if (campoEmFoco == self.site){
//        [self.site resignFirstResponder];
//    }
     
    //método diferente
    int posicao = [self.campoEmOrdem indexOfObject:campoEmFoco];
    if (posicao == [self.campoEmOrdem count] -1) {
        [self.view endEditing:YES];
    }else{
        UITextField *proximoCampo = self.campoEmOrdem[posicao+1];
        [proximoCampo becomeFirstResponder];
    }
}

- (void) criaContato {
    Contato *contato = [[Contato alloc] init];
    [self.contatos addObject:contato];
    
    NSLog(@"Contatos cadastrados: %d", [self.contatos count]);
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) escondeFormulario {
    [self.navigationController popViewControllerAnimated:YES];
}

- (id)init{
    self = [super init];
    if (self) {
        self.contatos = [[NSMutableArray alloc] init];
        
        self.navigationItem.title = @"Cadastro";
        
        UIBarButtonItem *cancelar = [[UIBarButtonItem alloc] initWithTitle:@"Cancelar"
                                                                     style:UIBarButtonItemStylePlain
                                                                    target:self
                                                                    action:@selector(escondeFormulario)];
        self.navigationItem.leftBarButtonItem = cancelar;
        
        UIBarButtonItem *adicionar = [[UIBarButtonItem alloc] initWithTitle:@"Adicionar"
                                                                      style:UIBarButtonItemStylePlain
                                                                     target:self
                                                                     action:@selector(criaContato)];
        self.navigationItem.rightBarButtonItem = adicionar;
    }
    return self;
}

@end
