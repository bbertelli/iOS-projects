//
//  Contato.h
//  ContatosIP67
//
//  Created by ios4230 on 10/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Contato : NSObject

@property NSString *nome;
@property NSString *telefone;
@property NSString *email;
@property NSString *end;
@property NSString *site;

@end
