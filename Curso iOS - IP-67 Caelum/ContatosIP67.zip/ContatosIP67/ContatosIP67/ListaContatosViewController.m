//
//  ListaContatosViewController.m
//  ContatosIP67
//
//  Created by ios4230 on 10/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import "ListaContatosViewController.h"
#import "FormularioContatoViewController.h"

@implementation ListaContatosViewController

- (id)init{
    if (self = [super init]) {
        self.title = @"Contatos";
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"+"
                                                                                  style:UIBarButtonItemStylePlain
                                                                                 target:self
                                                                                 action:@selector(mudaDeTela)];
    }
    return self;
}

- (void) mudaDeTela{
    FormularioContatoViewController *formulario = [[FormularioContatoViewController alloc] init];
    
    //modo de navegacao que cria novamente a tela e uma nova barrinha
    UINavigationController *novaBarrinha = [[UINavigationController alloc] initWithRootViewController:formulario];
    [self presentViewController:novaBarrinha
                       animated:YES
                     completion:nil];
    
    //modo de navegacao que troca uma tela pela outra na barrinha
//    [self.navigationController pushViewController:formulario
//                                         animated:YES];
}

@end
