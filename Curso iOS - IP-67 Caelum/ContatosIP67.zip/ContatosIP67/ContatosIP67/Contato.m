//
//  Contato.m
//  ContatosIP67
//
//  Created by ios4230 on 10/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import "Contato.h"

@implementation Contato

-(NSString *)description{
    return [NSString stringWithFormat:@"\nNome: %@\nTelefone: %@\nEmail: %@\nEndereço: %@\nSite: %@", self.nome,self.telefone,self.email,self.end,self.site];
}

@end
