//
//  FormularioContatoViewController.h
//  ContatosIP67
//
//  Created by ios4230 on 10/05/14.
//  Copyright (c) 2014 ios4230. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FormularioContatoViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *nome;
@property (weak, nonatomic) IBOutlet UITextField *telefone;
@property (weak, nonatomic) IBOutlet UITextField *email;
@property (weak, nonatomic) IBOutlet UITextField *end;
@property (weak, nonatomic) IBOutlet UITextField *site;
@property (strong, nonatomic) NSArray *campoEmOrdem;
@property (strong, nonatomic) NSMutableArray *contatos;

//- (IBAction)pegaDadosDoFormulario:(id)sender;
- (IBAction)proximoElemento:(UITextField *)campoEmFoco;

@end
